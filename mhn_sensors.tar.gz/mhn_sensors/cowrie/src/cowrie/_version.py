"""
Provides cowrie version information.
"""

# This file is auto-generated! Do not edit!
# Use `python -m incremental.update cowrie` to change this file.

from incremental import Version

__version__ = Version('cowrie', 1, 5, 3)
__all__ = ["__version__"]

ALTER TABLE `ttylog` CHANGE `ttylog` `ttylog` VARCHAR(100) NOT NULL;
ALTER TABLE `ttylog` ADD `size` INT(11) NOT NULL;
